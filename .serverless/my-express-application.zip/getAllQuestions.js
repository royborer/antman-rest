function dummy () {
    return "dummy";
}


module.exports = {
    dummy 
}